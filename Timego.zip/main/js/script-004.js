        import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
        import { getAuth, signInWithCustomToken, signInAnonymously, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
        import { getFirestore, doc, getDoc, setDoc, runTransaction, arrayUnion, serverTimestamp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";
        import { app, auth, db } from "/main/js/script-002.js";
        // IMPORTANT: PASTE YOUR FIREBASE CONFIGURATION HERE
        // The values below are from your previous paste and have been used to fix the path issue.
        const firebaseConfig = {
                apiKey: "AIzaSyA1nP6GuOZ201uX9IpgG5luRxO_6OPyBS0",
                authDomain: "timeego-35df7.firebaseapp.com",
                projectId: "timeego-35df7",
                storageBucket: "timeego-35df7.appspot.com",
                messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
                appId: "1:10386311177:web:0842e821cda6e7af9190d8"
        };
        
        const initialAuthToken = typeof __initial_auth_token !== 'undefined' ? __initial_auth_token : null;
        const appId = typeof __app_id !== 'undefined' ? __app_id : firebaseConfig.projectId;
        
        let userId = null;
        let currentUserData = null;
        let currentMonth = new Date().getMonth();
        let currentYear = new Date().getFullYear();
        
        
        
        // Function to check if two dates are the same day (ignoring time)
        const isSameDay = (d1, d2) => {
                return d1.getFullYear() === d2.getFullYear() &&
                        d1.getMonth() === d2.getMonth() &&
                        d1.getDate() === d2.getDate();
        };
        
        // Function to generate and display the calendar
        const generateCalendar = (checkinDates) => {
                calendarGridEl.innerHTML = '';
                const firstDayOfMonth = new Date(currentYear, currentMonth, 1).getDay();
                const daysInMonth = new Date(currentYear, currentMonth + 1, 0).getDate();
                
                currentMonthYearEl.textContent = new Date(currentYear, currentMonth).toLocaleString('default', { month: 'long', year: 'numeric' });
                
                // Add empty cells for the first day of the month
                for (let i = 0; i < firstDayOfMonth; i++) {
                        const emptyCell = document.createElement('div');
                        emptyCell.classList.add('p-2');
                        calendarGridEl.appendChild(emptyCell);
                }
                
                // Add day cells
                for (let day = 1; day <= daysInMonth; day++) {
                        const date = new Date(currentYear, currentMonth, day);
                        const dayCell = document.createElement('div');
                        dayCell.classList.add('p-2', 'rounded-lg', 'font-medium', 'flex', 'items-center', 'justify-center', 'aspect-square');
                        dayCell.textContent = day;
                        
                        // Check if this day is a check-in date
                        const isCheckedIn = checkinDates.some(checkinDateStr => {
                                const checkinDate = new Date(checkinDateStr);
                                return isSameDay(checkinDate, date);
                        });
                        
                        if (isCheckedIn) {
                                dayCell.classList.add('checked-in', 'text-white', 'bg-blue-600');
                        } else {
                                dayCell.classList.add('hover:bg-gray-200', 'transition-colors', 'duration-200', 'cursor-pointer');
                        }
                        
                        if (isSameDay(date, new Date())) {
                                dayCell.classList.add('ring-2', 'ring-blue-500', 'ring-offset-2');
                        }
                        
                        calendarGridEl.appendChild(dayCell);
                }
        };
        
        // Event listeners for calendar navigation
        prevMonthBtn.addEventListener('click', () => {
                currentMonth--;
                if (currentMonth < 0) {
                        currentMonth = 11;
                        currentYear--;
                }
                generateCalendar(currentUserData.checkinDates || []);
        });
        
        nextMonthBtn.addEventListener('click', () => {
                currentMonth++;
                if (currentMonth > 11) {
                        currentMonth = 0;
                        currentYear++;
                }
                generateCalendar(currentUserData.checkinDates || []);
        });
        
        // Function to handle the daily check-in
        const checkIn = async () => {
                if (!userId) {
                        showAlert("Please wait, user data is still loading.", false);
                        return;
                }
                
                checkinButton.disabled = true;
                
                // CORRECTED PATH: Using the new, valid format for document reference.
                const userDocRef = doc(db, 'artifacts', appId, 'users', userId);
                
                try {
                        // Use a transaction to ensure atomic read-then-write operation
                        await runTransaction(db, async (transaction) => {
                                const userDoc = await transaction.get(userDocRef);
                                
                                // Check if a document exists for the user
                                if (!userDoc.exists()) {
                                        // This case should be handled on initial load, but this is a safety check.
                                        transaction.set(userDocRef, {
                                                uid: userId,
                                                points: 10,
                                                lastCheckIn: serverTimestamp(),
                                                checkinDates: [new Date().toISOString()]
                                        });
                                        return;
                                }
                                
                                const data = userDoc.data();
                                const lastCheckInTime = data.lastCheckIn?.toDate();
                                
                                // Calculate time difference in milliseconds
                                const now = new Date();
                                const timeDifference = now.getTime() - (lastCheckInTime ? lastCheckInTime.getTime() : 0);
                                const twentyFourHoursInMs = 24 * 60 * 60 * 1000;
                                
                                if (lastCheckInTime && timeDifference < twentyFourHoursInMs) {
                                        const remainingTime = twentyFourHoursInMs - timeDifference;
                                        const hours = Math.floor(remainingTime / (1000 * 60 * 60));
                                        const minutes = Math.floor((remainingTime % (1000 * 60 * 60)) / (1000 * 60));
                                        const seconds = Math.floor((remainingTime % (1000 * 60)) / 1000);
                                        throw new Error(`You have already checked in today. Please try again in ${hours}h ${minutes}m ${seconds}s.`);
                                }
                                
                                // Perform the check-in
                                const newPoints = (data.points || 0) + 10;
                                const newCheckinDate = new Date().toISOString();
                                
                                transaction.update(userDocRef, {
                                        points: newPoints,
                                        lastCheckIn: serverTimestamp(),
                                        checkinDates: arrayUnion(newCheckinDate)
                                });
                                
                                // Update local state to reflect changes immediately in UI
                                currentUserData = {
                                        ...currentUserData,
                                        points: newPoints,
                                        checkinDates: [...(currentUserData.checkinDates || []), newCheckinDate],
                                };
                        });
                        
                        // Success message
                        userPointsEl.textContent = currentUserData.points;
                        generateCalendar(currentUserData.checkinDates || []);
                        showAlert("Daily check-in successful! You've earned 10 points.", true);
                        
                } catch (e) {
                        if (e.message.includes('You have already checked in today.')) {
                                showAlert(e.message, false);
                        } else {
                                console.error("Transaction failed: ", e);
                                showAlert("An error occurred during check-in. Please try again.", false);
                        }
                } finally {
                        checkinButton.disabled = false;
                }
        };
        
        checkinButton.addEventListener('click', checkIn);
        
        // Initialize Firebase and listen for auth state
        (async () => {
                try {
                        
                        // Sign in with the custom token or anonymously
                        if (initialAuthToken) {
                                await signInWithCustomToken(auth, initialAuthToken);
                        } else {
                                await signInAnonymously(auth);
                        }
                        
                        onAuthStateChanged(auth, async (user) => {
                                if (user) {
                                        userId = user.uid;
                                        // CORRECTED PATH: Using the new, valid format for document reference.
                                        const userDocRef = doc(db, 'artifacts', appId, 'users', userId);
                                        
                                        try {
                                                const docSnap = await getDoc(userDocRef);
                                                
                                                if (docSnap.exists()) {
                                                        currentUserData = docSnap.data();
                                                } else {
                                                        // Create the user's document if it doesn't exist
                                                        currentUserData = { uid: userId, points: 0, lastCheckIn: null, checkinDates: [] };
                                                        await setDoc(userDocRef, currentUserData);
                                                }
                                                
                                                // Update UI with initial data
                                                userPointsEl.textContent = currentUserData.points;
                                                generateCalendar(currentUserData.checkinDates || []);
                                                
                                        } catch (e) {
                                                console.error("Error fetching user data:", e);
                                                showAlert("Failed to load user data. Please refresh.", false);
                                        }
                                } else {
                                        // User is signed out
                                        userId = null;
                                        currentUserData = null;
                                        userPointsEl.textContent = '0';
                                        calendarGridEl.innerHTML = '';
                                        showAlert("Please sign in to access this feature.", false);
                                }
                        });
                        
                } catch (error) {
                        console.error("Failed to initialize Firebase:", error);
                        showAlert("Failed to connect to the database. Please try again.", false);
                }
        })();