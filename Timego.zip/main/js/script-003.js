 import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
 import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";
 import { getFirestore, doc, updateDoc, onSnapshot, collection, getDocs } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";
 import { app, auth, db } from "/main/js/script-002.js";
 
 // Global variables
 let images = [];
 let currentIndex = 0;
 let autoSlideInterval;
 const AUTO_SLIDE_DELAY = 5000;
 let touchStartX = 0;
 let touchEndX = 0;
 const SWIPE_THRESHOLD = 50;
 
 //Already defined in global state variable 
 profileInput.addEventListener('change', changeProfilePics);
 darkModeToggle.addEventListener('click', toggleDarkMode);
 
 
 previewPic.addEventListener('click', () => {
     showConfirm(
         "Modify Profile Avatar?",
         () => {
             profileInput.click()
         }, () => { previewPic.classList.toggle("active") }
     );
 })
 
 async function changeProfilePics() {
     const user = auth.currentUser;
     if (!user || !currentUserData) return;
     
     const file = this.files[0];
     if (file) {
         showLoading(true);
         const reader = new FileReader();
         reader.onload = async function(e) {
             const pics = e.target.result;
             try {
                 const userDocRef = doc(db, "TimeEgo-users", user.uid);
                 await updateDoc(userDocRef, { pic: pics });
                 
             } catch (error) {
                 console.error("Failed to save pics preference:", error);
             }
             showAlert('Profile Picture Updated successfully ');
             showLoading(false)
             previewPic.src = pics;
         };
         reader.readAsDataURL(file);
     }
 }
 
 async function toggleDarkMode() {
     const user = auth.currentUser;
     if (!user || !users) return;
     
     if (currentUserData.acctPlan === 'bS') {
         showAlert('Upgrade to use this feature.');
         return;
     }
     
     const currentTheme = html.getAttribute('data-theme');
     const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
     html.setAttribute('data-theme', newTheme);
     try {
         const userDocRef = doc(db, "TimeEgo-users", user.uid);
         await updateDoc(userDocRef, { savedTheme: newTheme });
     } catch (error) {
         console.error("Failed to save theme preference:", error);
     }
 }
 
 // --- Firebase Data Fetching ---
 async function handleImageCarousel() {
     loaderContainer.style.display = 'flex';
     try {
         // --- CORRECTED: Use modular Firebase v9+ syntax ---
         const imagesCollection = collection(db, 'home-images');
         const imagesSnapshot = await getDocs(imagesCollection);
         
         // --- CORRECTED: Populate the global 'images' array ---
         images = imagesSnapshot.docs.map(doc => doc.data());
         // --- CORRECTED: Check 'images' array and handle empty state ---
         if (images.length > 0) {
             loadSlide(currentIndex);
             createDots();
             startAutoSlide();
         } else {
             sliderImage.alt = 'No images found.';
         }
         
     } catch (error) {
         console.error("Error fetching carousel images:", error);
         // Assuming showAlert is a defined function
         showAlert("Failed to load application data. Please try again later.");
         sliderImage.alt = 'Error loading images.';
     } finally {
         loaderContainer.style.display = 'none';
     }
 }
 
 // --- Function to load a specific slide ---
 function loadSlide(index) {
     if (images.length === 0) return;
     currentIndex = (index + images.length) % images.length;
     sliderImage.src = images[currentIndex].url;
     sliderImage.alt = images[currentIndex].alt;
     sliderImage.addEventListener('click', () => {
         // Assuming showPage is defined elsewhere and handles the navigation
         if (images[currentIndex].tab) {
             showPage(images[currentIndex].tab);
         }
     });
     updateDots();
 }
 
 // --- Navigation Functions ---
 function nextSlide() {
     loadSlide(currentIndex + 1);
     resetAutoSlide();
 }
 
 function prevSlide() {
     loadSlide(currentIndex - 1);
     resetAutoSlide();
 }
 
 // --- Auto-slide Functions ---
 function startAutoSlide() {
     clearInterval(autoSlideInterval);
     autoSlideInterval = setInterval(nextSlide, AUTO_SLIDE_DELAY);
 }
 
 function resetAutoSlide() {
     clearInterval(autoSlideInterval);
     startAutoSlide();
 }
 
 // --- Navigation Dots Functions ---
 function createDots() {
     dotsContainer.innerHTML = '';
     images.forEach((_, index) => {
         const dot = document.createElement('span');
         dot.classList.add('dot');
         dot.dataset.index = index;
         dot.addEventListener('click', () => {
             loadSlide(index);
             resetAutoSlide();
         });
         dotsContainer.appendChild(dot);
     });
     updateDots();
 }
 
 function updateDots() {
     const dots = document.querySelectorAll('.dot');
     dots.forEach((dot, index) => {
         dot.classList.toggle('active', index === currentIndex);
     });
 }
 
 // --- Touch/Swipe Event Handlers ---
 sliderContainer.addEventListener('touchstart', (e) => {
     touchStartX = e.touches[0].clientX;
 });
 
 sliderContainer.addEventListener('touchend', (e) => {
     touchEndX = e.changedTouches[0].clientX;
     handleGesture();
 });
 
 function handleGesture() {
     const deltaX = touchEndX - touchStartX;
     if (Math.abs(deltaX) > SWIPE_THRESHOLD) {
         if (deltaX < 0) {
             nextSlide();
         } else {
             prevSlide();
         }
     }
 }
 // --- Event Listeners ---
 prevBtn.addEventListener('click', prevSlide);
 nextBtn.addEventListener('click', nextSlide);
 
 
 //for bank account saving
 async function handleSaveBankDetails() {
     const user = auth.currentUser;
     if (!user) {
         showAlert("You must be logged in to save bank details.");
         return;
     }
     const bankName = bankNameElem.textContent.trim();
     const accountNumber = accountNumberElem.textContent.trim();
     const accountName = accountNameElem.textContent.trim();
     if (!bankName || !accountNumber || !accountName) {
         showAlert("All bank details fields are required.");
         return;
     }
     if (accountNumber.length !== 10) {
         showAlert('Account number length must be 10digits ');
         return
     }
     else {
         showConfirm(
             'Are you sure this details are Valid?',
             async () => {
                     try {
                         const userDocRef = doc(db, "TimeEgo-users", user.uid);
                         await updateDoc(userDocRef, {
                             bankDetails: {
                                 bankName: bankName,
                                 accountNumber: accountNumber,
                                 accountName: accountName,
                             }
                         });
                         showAlert("Bank details saved successfully!");
                     }
                     catch (error) {
                         console.error("Error saving bank details:", error);
                         showAlert("Failed to save bank details. Please try again.");
                     }
                 },
                 () => {
                     //	showAlert('Operation Cancelled!!');
                     editButton.click();
                 });
     }
 }
 
 // State and DOM elements
 let isEditing = false;
 let editButton;
 let accountNameElem, bankNameElem, accountNumberElem, bankStatusElem;
 
 // Toggles the editable state of the card fields
 function toggleEditMode() {
     isEditing = !isEditing;
     const fields = [accountNameElem, bankNameElem, accountNumberElem];
     fields.forEach(field => {
         if (field) {
             field.contentEditable = isEditing;
             if (isEditing) {
                 field.classList.add('editable');
             } else {
                 field.classList.remove('editable');
             }
         }
     });
     
     if (editButton) {
         if (isEditing) {
             editButton.innerHTML = `
                <svg class="edit-icon" viewBox="0 0 24 24"><path d="M9 16.2L4.8 12l-1.4 1.4L9 19 21 7l-1.4-1.4L9 16.2z"/></svg>Done`;
             //   showMessage("Edit mode enabled. Click on text to change.");
         } else {
             editButton.innerHTML = `
                <svg class="edit-icon" viewBox="0 0 24 24"><path d="M3 17.25V21h3.75L18.75 9.75l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>Edit`;
             handleSaveBankDetails();
         }
     }
 }
 
 // Sets up the initial HTML and listeners
 function setupUI() {
     const paymentBox = document.querySelector('#payment-box');
     if (paymentBox) {
         paymentBox.innerHTML = `
		                    <div class="top-affiliates-header"><br /><br>
                        <h2>Add Bank Details</h2>
                    </div>
            <div class="atm-card">
                <button id="editButton" class="edit-button">
                    <svg class="edit-icon" viewBox="0 0 24 24">
                        <path d="M3 17.25V21h3.75L18.75 9.75l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34c-.39-.39-1.02-.39-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z" />
                    </svg>Edit</button>
                <p class="card-detail username" id="accountName">Account name</p>
                <p class="card-detail">Payments account <span id="bankStatus">Not verified</span></p>
                <hr />
                <p class="card-detail account-number" id="accountNumber">Account number</p>
                <p class="card-detail account-name" id="bankName">Bank name</p>
            </div>`;
         
         // Assign DOM elements to variables AFTER they have been added to the page
         editButton = document.getElementById('editButton');
         accountNameElem = document.getElementById('accountName');
         bankNameElem = document.getElementById('bankName');
         accountNumberElem = document.getElementById('accountNumber');
         
         // Add the event listener to the edit button
         if (editButton) {
             editButton.addEventListener('click', toggleEditMode);
         } else {
             console.error("Edit button not found.");
         }
     }
     
 }
 
 
 let acctDetails = [];
 // --- Firebase Data Fetching ---
 async function handleDepositAcctDetails() {
     showLoading(true)
     //  loaderContainer.style.display = 'flex';
     try {
         // --- CORRECTED: Use modular Firebase v9+ syntax ---
         const acctDetailsCollection = collection(db, 'depositAcct');
         const acctDetailsSnapshot = await getDocs(acctDetailsCollection);
         // --- CORRECTED: Populate the global 'images' array ---
         acctDetails = acctDetailsSnapshot.docs.map(doc => doc.data());
         
         // --- CORRECTED: Check 'images' array and handle empty state ---
         if (acctDetails.length > 0) {
             loadDepositDetails();
         } else {
             document.querySelector(".rechargeTab").innerHTML = `  <div class="no-referrals">
                    <p>Can't load account, Try Again later..</p>
                    <i class="fas fa-robot"></i>
                </div>`
         }
         
     } catch (error) {
         console.error("Error fetching bank account:", error);
         // Assuming showAlert is a defined function
         showAlert("Failed to load application data. Please try again later.");
         sliderImage.alt = 'Error loading images.';
     } finally {
         showLoading(false)
         //      loaderContainer.style.display = 'none';
     }
 }
 
 
 let startTransferBtn = document.createElement("button");
 startTransferBtn.textContent = 'I have made this Bank Transfer';
 startTransferBtn.className = 'action';
 
 function loadDepositDetails(param) {
     acctDetails.forEach(acctDetail => {
         setTimeout(() => {
             document.querySelector(".rechargeTab").innerHTML += ` <div class="top-affiliates-header">
                <h2>Transfer Details</h2>
                <button class="see-more-btn" onclick="showAlert('Something went wrong, ')">
                    <span>Learn More</span>
                    <i class="fas fa-chevron-right"></i>
                </button>
            </div>
            
            <p style="font-size: small;">Proceed to your bank app to complete this Transfer</p>
            <br>
            <div class="box">
                <label for="aA">Amount(Min):</label>
                <input type="text" name="aA" id="amountToCopy" value=" ₦ ${acctDetail.amount}" readonly>
                <button class="cancel" onclick="copyText('amountToCopy')"><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 448 512" fill="var(--accent-clr)" height="20">
                        <path d="M384 336l-192 0c-8.8 0-16-7.2-16-16l0-256c0-8.8 7.2-16 16-16l140.1 0L400 115.9 400 320c0 8.8-7.2 16-16 16zM192 384l192 0c35.3 0 64-28.7 64-64l0-204.1c0-12.7-5.1-24.9-14.1-33.9L366.1 14.1c-9-9-21.2-14.1-33.9-14.1L192 0c-35.3 0-64 28.7-64 64l0 256c0 35.3 28.7 64 64 64zM64 128c-35.3 0-64 28.7-64 64L0 448c0 35.3 28.7 64 64 64l192 0c35.3 0 64-28.7 64-64l0-32-48 0 0 32c0 8.8-7.2 16-16 16L64 464c-8.8 0-16-7.2-16-16l0-256c0-8.8 7.2-16 16-16l32 0 0-48-32 0z" />
                    </svg></button>
            </div>
            <br />
            <div class="box">
                <label for="aC">Account Number:</label>
                <input type="number" name="aC" id="accountNumberToCopy" value="${acctDetail.acctNumber}" readonly />
                <button class="cancel" onclick="copyText('accountNumberToCopy')"><svg xmlns="http://www.w3.org/2000/svg" fill="var(--accent-clr)" viewBox="0 0 448 512" height="20">
                        <path d="M384 336l-192 0c-8.8 0-16-7.2-16-16l0-256c0-8.8 7.2-16 16-16l140.1 0L400 115.9 400 320c0 8.8-7.2 16-16 16zM192 384l192 0c35.3 0 64-28.7 64-64l0-204.1c0-12.7-5.1-24.9-14.1-33.9L366.1 14.1c-9-9-21.2-14.1-33.9-14.1L192 0c-35.3 0-64 28.7-64 64l0 256c0 35.3 28.7 64 64 64zM64 128c-35.3 0-64 28.7-64 64L0 448c0 35.3 28.7 64 64 64l192 0c35.3 0 64-28.7 64-64l0-32-48 0 0 32c0 8.8-7.2 16-16 16L64 464c-8.8 0-16-7.2-16-16l0-256c0-8.8 7.2-16 16-16l32 0 0-48-32 0z" />
                    </svg></button>
            </div>
            <br>
            <div class="box">
                <label for="bN">Bank Name:</label>
                <input type="text" name="bN" id="" value="${acctDetail.bankName}" readonly />
            </div>
            <br />
            <div class="box">
                <label for="aN">Account Name:</label>
                <input name="aN" value="${acctDetail.acctName}" readonly>
            </div><br />
            <p style="font-size: small;">Pay to the above account to proceed account recharge as this account is only for this transaction</p>
            <br />
            `;
             document.querySelector(".rechargeTab").appendChild(startTransferBtn);
         }, 9000);
     });
 }
 
 startTransferBtn.addEventListener("click", startTransfer)
 
 function startTransfer() {
     document.querySelector(".rechargeTab").innerHTML = `
     <div id="spinner" style="display:block;margin: 20px 0;">
                <br />
                <div class="spinner" style="font-size: 13px;"></div>
                <br />
                <p> Wait while we confirm your payment... </p><br>
                <div class="bc">
                    <p style="float: left; font-size: 12pt;font-weight: 600;; padding-top: 10px"> Payment Made
                    <div class="bb"><i class="fa-solid fa-circle-check"></i></div>
                    </p>
                </div>
                <br>
                <div class="bc">
                    <p style="font-size: 12pt;font-weight: 600;; padding-top: 10px;">Confirming Payment
                    <div class="spinners"></div>
                    </p>
                </div>
            </div>`;
     
     setTimeout(() => {
         document.querySelector(".rechargeTab").innerHTML = `          
         <div style="display:block; margin:20px 0">
                <p>Payment pending not confirmed, need help?<a href="#">click here</a></p>
                <br>
            </div>`
         
         
         showAlert('Payments not confirmed pending, Action required');
     }, 20000);
 }
 
 
 document.addEventListener('DOMContentLoaded', () => {
     setupUI();
     handleImageCarousel()
     handleDepositAcctDetails();
     loadDepositDetails()
 });