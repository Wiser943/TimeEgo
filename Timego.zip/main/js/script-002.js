// This file includes all necessary Firebase imports.
import { initializeApp } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-auth.js";
import { getFirestore, doc, updateDoc, onSnapshot, collection, getDocs, runTransaction, query, where, orderBy, getDoc, FieldValue } from "https://www.gstatic.com/firebasejs/10.12.3/firebase-firestore.js";


// --- Firebase Initialization ---
// IMPORTANT: Replace the placeholder values with your actual Firebase project configuration.
const firebaseConfig = {
	apiKey: "AIzaSyA1nP6GuOZ201uX9IpgG5luRxO_6OPyBS0",
	authDomain: "timeego-35df7.firebaseapp.com",
	projectId: "timeego-35df7",
	storageBucket: "timeego-35df7.appspot.com",
	messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
	appId: "1:10386311177:web:0842e8e7af9190d8"
};

export const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const db = getFirestore(app);

// --- Global State Variables ---
let currentUserData = null;
let users = null;
let currentUserTasks = [];
let userDocRef;


// --- Main Entry Point: onAuthStateChanged ---
document.addEventListener('DOMContentLoaded', () => {
	showLoading(true);
	onAuthStateChanged(auth, (user) => {
		showLoading(true);
		// FIX: Added a robust check for user and user.uid to prevent TypeError.
		if (user && user.uid) {
			userDocRef = doc(db, "TimeEgo-users", user.uid);
			
			// Calls moved inside this block
			checkAndAwardReferralPoints(user);
			displayReferralInfo(user);
			getTopReferrersByUsername(user);
			loadAllTasks(user.uid);
			
			onSnapshot(userDocRef, (docSnap) => {
				if (docSnap.exists()) {
					showLoading(false);
					currentUserData = docSnap.data();
					users = docSnap.data();
					
					welcomeUsernames.forEach(username => username.textContent = currentUserData.username);
					userEmails.forEach(userEmail => userEmail.textContent = currentUserData.email);
					userId.forEach(userid => {
						userid.innerHTML = `ID: ${users.userid}  <svg xmlns="http://www.w3.org/2000/svg" fill="var(--text-color-light)" viewBox="0 0 448 512" height="10"><path d="M384 336l-192 0c-8.8 0-16-7.2-16-16l0-256c0-8.8 7.2-16 16-16l140.1 0L400 115.9 400 320c0 8.8-7.2 16-16 16zM192 384l192 0c35.3 0 64-28.7 64-64l0-204.1c0-12.7-5.1-24.9-14.1-33.9L366.1 14.1c-9-9-21.2-14.1-33.9-14.1L192 0c-35.3 0-64 28.7-64 64l0 256c0 35.3 28.7 64 64 64zM64 128c-35.3 0-64 28.7-64 64L0 448c0 35.3 28.7 64 64 64l192 0c35.3 0 64-28.7 64-64l0-32-48 0 0 32c0 8.8-7.2 16-16 16L64 464c-8.8 0-16-7.2-16-16l0-256c0-8.8 7.2-16 16-16l32 0 0-48-32 0z"/></svg>`;
						userid.addEventListener('click', () => {
							navigator.clipboard.writeText(users.userid).then(() => {
								showAlert('User Id Copied to clipboard! ♟️');
							}).catch(err => {
								console.error('Failed to copy text: ', err);
							});
						});
					});
					
					let isBalanceVisible = JSON.parse(localStorage.getItem("balState"));
					
					function toggleBalance() {
						isBalanceVisible = !isBalanceVisible;
						localStorage.setItem('balState', JSON.stringify(isBalanceVisible));
						updateBalanceVisibility();
					}
					
					function updateBalanceVisibility() {
						balanceElement.forEach((balElmt) => {
							if (!isBalanceVisible) {
								balElmt.textContent = "*****.**";
								document.getElementById('eyeOpen').classList.add('hidden');
								document.getElementById('eyeClosed').classList.remove('hidden');
							} else {
								balElmt.textContent = users.ib.toLocaleString('en-NG', { minimumFractionDigits: 2 });
								document.getElementById('eyeOpen').classList.remove('hidden');
								document.getElementById('eyeClosed').classList.add('hidden');
							}
						});
					}
					updateBalanceVisibility();
					if (toggleBalButton) toggleBalButton.addEventListener('click', toggleBalance);
					
					if (users.acctPlan === 'bS') {
						planBtn.textContent = 'STARTER plan';
						document.documentElement.style.setProperty('--accent-clr', '#4070C0');
						document.documentElement.style.setProperty('--lg-accent-bg', '#E0EFFF');
					} else if (users.acctPlan === 'gD') {
						planBtn.textContent = 'CLASSIC plan';
						document.documentElement.style.setProperty('--accent-clr', '#65319C');
						document.documentElement.style.setProperty('--lg-accent-bg', '#B79DEA');
					} else if (users.acctPlan === 'Pm') {
						planBtn.textContent = 'PREMIUM plan';
						document.documentElement.style.setProperty('--accent-clr', '#BE5922');
					}
					if (planBtn) planBtn.addEventListener('click', () => {
						if (users.acctPlan !== 'Pm') {
							showAlert('Upgrade plan to Earn more.. 💰');
						} else {
							showAlert('🎉 Congratulations on being a Premium User... 🎉');
						}
					});
					document.getElementById('wBonus').textContent = `₦${users.wBonus.toLocaleString('en-NG', { minimumFractionDigits: 2 })}`;
					const savedTheme = currentUserData.savedTheme || 'light';
					html.setAttribute('data-theme', savedTheme);
					const savedPic = currentUserData.pic || "https://placehold.co/40x40/FF69B4/FFFFFF?text=P";
					previewPics.forEach(previewPic => previewPic.src = savedPic);
					
					if (users.bankDetails) {
						document.getElementById('bankName').textContent = users.bankDetails.bankName;
						document.getElementById('accountNumber').textContent = users.bankDetails.accountNumber;
						document.getElementById('accountName').textContent = users.bankDetails.accountName;
						if (users.bankDetails.accountName === users.username) {
							document.getElementById('bankStatus').textContent = "Verified";
							document.getElementById('bankStatus').style.backgroundColor = "green";
						}
					} else {
						document.getElementById('editButton').style.display = "flex";
					}
					
					let refBal = !users.refPoints ? 0 : users.refPoints;
					let inviteLink = `${window.location.origin}/accounts/account.html?tab=signup-page&ref=${users.userid}`;
					document.getElementById('refEarnings').textContent = `₦${refBal.toLocaleString('en-NG', { minimumFractionDigits: 2 })}`;
					
					refferalCode.querySelector('.referral-link-text').value = inviteLink;
					refferalCode.addEventListener('click', () => {
						navigator.clipboard.writeText('Hello, this is a platform am part of and pays well.. Use my link to register 👇👇' + '' + inviteLink).then(() => showAlert('Referral Link copied Success ♟️')).catch((err) => showAlert('Failed to copy link: ', err));
					});
					
					if (users.referrerUid && users.referrerUid.length < 10 || users.referrerUid.length === 10 || users.referrerUid === "") {
						referer.textContent = "TimeEgo";
					} else if (users.referrerUid.length > 10) {
						referer.textContent = users.referrerUid;
					}
				} else {
					
					console.error("User data not found in Firestore. Signing out.");
					
					signOut(auth);
				}
			}, (error) => {
				console.error("Error with real-time listener:", error);
			});
		} else {
			calendarGridEl.innerHTML = '';
			console.log("User not logged in. Redirecting to login page...");
			window.location.href = "/accounts/account.html?tab=login-page";
			showLoading(false);
		}
	});
});


// --- Task-Related Functions ---
async function loadAllTasks(userId) {
	try {
		if (!userId) {
			console.error("User ID is not defined. Cannot load tasks.");
			return;
		}
		
		const globalTasksSnapshot = await getDocs(collection(db, 'user-task'));
		const userCompletedTasksSnapshot = await getDocs(collection(userDocRef, 'completed-tasks'));
		
		const completedTasksMap = {};
		userCompletedTasksSnapshot.forEach(doc => {
			const data = doc.data();
			completedTasksMap[data.taskId] = data.lastCompleted;
		});
		
		const now = Date.now();
		const twentyFourHours = 24 * 60 * 60 * 1000;
		
		currentUserTasks = globalTasksSnapshot.docs.map(doc => {
			const task = { id: doc.id, ...doc.data(), status: 'Not started' };
			
			if (completedTasksMap[task.id]) {
				const lastCompletedTimestamp = completedTasksMap[task.id].toMillis();
				if ((now - lastCompletedTimestamp) < twentyFourHours) {
					task.status = 'Completed';
					task.lastCompleted = completedTasksMap[task.id];
				}
			}
			return task;
		});
		
		renderTasks();
	} catch (error) {
		console.error("Error loading tasks: ", error);
		showAlert("Error loading tasks.");
	}
}

async function handleTaskClick(taskId, taskHref, taskAmount) {
	const taskIndex = currentUserTasks.findIndex(task => task.id === taskId);
	if (taskIndex === -1) {
		console.error(`Task with ID ${taskId} not found.`);
		showAlert("Error: Task not found.");
		return;
	}
	
	const task = currentUserTasks[taskIndex];
	const now = Date.now();
	const twentyFourHours = 24 * 60 * 60 * 1000;
	
	if (task.status === 'Completed' && task.lastCompleted && (now - task.lastCompleted.toMillis() < twentyFourHours)) {
		const timeLeft = twentyFourHours - (now - task.lastCompleted.toMillis());
		const hours = Math.floor(timeLeft / (1000 * 60 * 60));
		const minutes = Math.floor((timeLeft % (1000 * 60 * 60)) / (1000 * 60));
		showAlert(`You can only perform this task once every 24 hours. Please wait ${hours}h ${minutes}m.`);
		return;
	}
	
	try {
		await runTransaction(db, async (transaction) => {
			const userDoc = await transaction.get(userDocRef);
			if (!userDoc.exists) {
				throw new Error("User document does not exist!");
			}
			const currentBalance = userDoc.data().ib || 0;
			const newBalance = currentBalance + taskAmount;
			const newTaskBal = (userDoc.data().totalTaskBal || 0) + taskAmount;
			console.log(newBalance)
			transaction.update(userDocRef, { ib: newBalance, totalTaskBal: newTaskBal });
			
			const completedTaskDocRef = doc(collection(userDocRef, 'completed-tasks'), taskId);
			console.log(completedTaskDocRef)
			transaction.set(completedTaskDocRef, {
				taskId: taskId,
				lastCompleted: FieldValue.serverTimestamp()
			});
			/*
						const userDocRef = doc(db, "TimeEgo-users", user.uid);
					await updateDoc(userDocRef, {
						[`tasks.${taskId}`]: { status: 'Completed', lastCompleted: now },
						ib: currentUserData.ib + taskAmount,
						totalTaskBal: currentUserData.totalTaskBal + taskAmount
					});*/
			
		});
		
		
		if (taskHref && taskHref !== '#') {
			window.open(taskHref, '_blank');
		}
		
		task.status = 'Completed';
		task.lastCompleted = firebase.firestore.Timestamp.now();
		renderTasks();
		
		showAlert(`Task completed! You earned ${taskAmount.toFixed(2)} points.`);
	} catch (error) {
		console.error("Transaction failed: ", error);
		showAlert("An error occurred. Points were not awarded.");
	}
}

function renderTasks() {
	if (!tasksList) {
		console.error("tasks-list element not found.");
		return;
	}
	tasksList.innerHTML = "";
	currentUserTasks.forEach(task => {
		if (task.status === 'Completed') {
			return;
		}
		
		const taskCard = document.createElement('div');
		taskCard.className = 'task-card';
		
		let statusClass = 'status-not-started';
		taskCard.innerHTML = `
            <div class="task-icon-wrapper">
                <i class="fab ${task.icon} icon"></i>
            </div>
            <div class="task-details">
                <div class="task-title">${task.title}</div>
                <div class="task-description">${task.description}</div>
                ${task.warning ? `<div class="warning-message">${task.warning}</div>` : ''}
                <div class="task-status-section">
                    <span class="task-amount">₦${task.amount.toLocaleString('en-NG', { minimumFractionDigits: 2 })}</span>
                    <span class="task-status-badge ${statusClass}">${task.status}</span>
                </div>
            </div>
        `;
		taskCard.addEventListener('click', () => handleTaskClick(task.id, task.href, task.amount));
		tasksList.appendChild(taskCard);
	});
}


// --- Referral-related Functions ---
async function checkAndAwardReferralPoints(currentUser) {
	if (!currentUser.emailVerified) {
		document.getElementById('dashboard-status').textContent = 'Unverified.';
		return;
	}
	
	const calculatePercentage = (percentage, value) => {
		const numericValue = parseFloat(value) || 0;
		return (numericValue * percentage) / 100;
	};
	
	try {
		const userDocRef = doc(db, 'TimeEgo-users', currentUser.uid);
		const userDocSnap = await getDoc(userDocRef);
		const userData = userDocSnap.data();
		
		if (userData && userData.referrerUid && !userData.referralAwarded) {
			showLoading(true);
			
			await runTransaction(db, async (transaction) => {
				const referrerDocRef = doc(db, 'TimeEgo-users', userData.referrerUid);
				const referrerDocSnap = await transaction.get(referrerDocRef);
				
				if (!referrerDocSnap.exists()) {
					throw new Error("Referrer does not exist!");
				}
				
				const referrerData = referrerDocSnap.data();
				const ibValue = referrerData.ib || 0;
				const points = calculatePercentage(5, ibValue);
				const newPoints = (referrerData.refPoints || 0) + points;
				const newIb = (referrerData.ib || 0) + points;
				transaction.update(referrerDocRef, { refPoints: newPoints, ib: newIb });
				transaction.update(userDocRef, { referralAwarded: true, emailVerified: true });
			});
			document.getElementById('dashboard-status').style.color = "green";
			document.getElementById('dashboard-status').textContent = 'Verified';
			showAlert("Welcome onboard!");
		}
	} catch (error) {
		console.error("Error in referral points logic:", error);
		document.getElementById('dashboard-status').textContent = "";
	} finally {
		showLoading(false);
	}
}

async function displayReferralInfo(currentUser) {
	try {
		const q = query(
			collection(db, 'TimeEgo-users'),
			where('referrerUid', '==', currentUser.uid),
			orderBy('createdAt', 'asc')
		);
		
		const querySnapshot = await getDocs(q);
		
		const referralCount = querySnapshot.size;
		const referralCountElement = document.getElementById('referral-count');
		if (referralCountElement) {
			referralCountElement.textContent = `${referralCount} user(s)`;
		}
		
		const referralListContainer = document.getElementById('referral-list-container');
		if (!referralListContainer) {
			console.error("HTML element with ID 'referral-list-container' not found.");
			return;
		}
		
		referralListContainer.innerHTML = '';
		
		if (querySnapshot.empty) {
			referralListContainer.innerHTML = `<div class="no-referrals"><p>You don't have any referrals yet</p><i class="fas fa-robot"></i></div>`;
			return;
		}
		
		let referralListHTML = `<table><thead><tr><th>S/N</th><th>Referred ID</th><th>Email Status</th><th>Date Joined</th></tr></thead><tbody>`;
		
		let counter = 1;
		querySnapshot.forEach((doc) => {
			const userData = doc.data();
			const referredId = doc.id.substring(0, 10) + '...';
			const emailStatus = userData.emailVerified ? 'Verified' : 'Pending';
			const createdAt = userData.createdAt ? userData.createdAt.toDate().toLocaleDateString() : 'N/A';
			
			referralListHTML += `<tr><td>${counter++}</td><td>${referredId}</td><td>${emailStatus}</td><td>${createdAt}</td></tr>`;
		});
		
		referralListHTML += `</tbody></table>`;
		referralListContainer.innerHTML = referralListHTML;
	} catch (error) {
		console.error("Error fetching referral info:", error);
		document.getElementById('referral-count').textContent = `Can't load.`;
		document.getElementById('referral-list-container').innerHTML = `<div class="no-referrals"><p>Something went wrong, Try again later..</p><i class="fas fa-robot"></i></div>${error}`;
	} finally {
		showLoading(false);
	}
}

async function getTopReferrersByUsername(currentUser) {
	if (!currentUser) {
		console.error("User not authenticated.");
		document.getElementById('top-referrers-container').innerHTML = `<p>Please sign in to view this content.</p>`;
		return;
	}
	
	try {
		const allUsersSnapshot = await getDocs(query(collection(db, 'TimeEgo-users')));
		const usersData = {};
		allUsersSnapshot.forEach(userDoc => {
			const userData = userDoc.data();
			const userUID = userDoc.id;
			
			if (!usersData[userUID]) {
				usersData[userUID] = {
					username: userData.username || 'Anonymous',
					referrals: 0
				};
			}
			
			if (userData.referrerUid) {
				if (usersData[userData.referrerUid]) {
					usersData[userData.referrerUid].referrals++;
				}
			}
		});
		
		const sortedReferrers = Object.values(usersData).sort((userA, userB) => userB.referrals - userA.referrals).slice(0, 3);
		
		const topReferrersContainer = document.getElementById('top-referrers-container');
		if (!topReferrersContainer) {
			console.error("HTML element with ID 'top-referrers-container' not found.");
			return;
		}
		
		let htmlContent = "";
		if (sortedReferrers.length === 0 || sortedReferrers[0].referrals === 0) {
			htmlContent += `<div class="no-referrals"><p>You're all caught up for now, come back next time</p><i class="fas fa-robot"></i></div>`;
		} else {
			sortedReferrers.forEach((referrer) => {
				if (referrer.referrals > 0) {
					htmlContent += `
                        <div class="affiliate-card purple">
                            <img src="https://placehold.co/60x60/800080/FFFFFF?text=${referrer.username.charAt(0).toUpperCase()}" alt="${referrer.username} Avatar" class="affiliate-avatar" loading="lazy">
                            <p class="affiliate-amount">${referrer.referrals} referral(s)</p>
                            <p class="affiliate-name">${referrer.username.substring(0, 10) + '...'}</p>
                        </div>`;
				}
			});
		}
		topReferrersContainer.innerHTML = htmlContent;
	} catch (error) {
		console.error("Error fetching top referrers:", error);
		document.getElementById('top-referrers-container').innerHTML = `<div class="no-referrals"><p>Something went wrong..</p><i class="fas fa-robot"></i></div>`;
	} finally {
		showLoading(false);
	}
}