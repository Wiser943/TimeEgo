//For universal or Global scripting 
// Get the toggle button and balance elements
const html = document.documentElement;
const darkModeToggle = document.getElementById('darkModeToggle');
const tasksList = document.getElementById('tasks-list');
const profileInput = document.getElementById('profilePic');
const previewPic = document.getElementById('previewPic');

const userPointsEl = document.getElementById('user-points');
const checkinButton = document.getElementById('checkin-button');
const statusMessageEl = document.getElementById('status-message');
const currentMonthYearEl = document.getElementById('current-month-year');
const calendarGridEl = document.getElementById('calendar-grid');
const prevMonthBtn = document.getElementById('prev-month');
const nextMonthBtn = document.getElementById('next-month');

const toggleBalButton = document.getElementById('toggle-balance');
const userId = document.querySelectorAll('.userid');
const referer = document.getElementById('inviter');
const refferalCode = document.getElementById('refferalCode');
// For image slider
const sliderImage = document.getElementById('slider-image');
const prevBtn = document.getElementById('prevBtn');
const nextBtn = document.getElementById('nextBtn');
const dotsContainer = document.querySelector('.dots-container');
const sliderContainer = document.querySelector('.image-slider-container');

// Custom Alert Modal elements
const customAlertModal = document.getElementById('custom-alert-modal');
const alertMessage = document.getElementById('alert-message');
const alertOkButton = document.getElementById('alert-ok-button');
const closeAlertButton = document.querySelector('#custom-alert-modal .close-button');
const loaderContainer = document.getElementById('loader-container');
// Custom Confirm Modal elements
const customConfirmModal = document.getElementById('custom-confirm-modal');
const confirmMessage = document.getElementById('confirm-message');
const confirmYesButton = document.getElementById('confirm-yes-button');
const confirmNoButton = document.getElementById('confirm-no-button');

const tabItems = document.querySelectorAll('.tab-item');
const balanceElement = document.querySelectorAll('.balance');

//variable decelerations
const planBtn = document.querySelector('.plan-btn');
const previewPics = document.querySelectorAll('.userImg');
const welcomeUsernames = document.querySelectorAll('.username');
const userEmails = document.querySelectorAll('.useremail');
// to get object params from searchlist
const urlParams = new URLSearchParams(window.location.search);
const tabParam = urlParams.get('tab');
/**
 * Displays a custom alert modal with the given message.
 * @param {string} message - The message to display in the alert.
 * @param{boolean} isSuccess 
 */
function showAlert(message, isSuccess) {
	alertMessage.innerHTML = message;
	customAlertModal.style.display = 'flex'; // Use flex to center
	customAlertModal.className = `text-lg font-medium mb-4 ${isSuccess ? 'text-green-600' : 'text-red-600'}`;
	//modalEl.classList.remove('hidden');
}

/**
 * Displays a custom confirmation modal with a message and callbacks for Yes/No.
 * @param {string} message - The message to display.
 * @param {function} onConfirm - Callback function if 'Yes' is clicked.
 * @param {function} onCancel - Callback function if 'No' is clicked.
 */
function showConfirm(message, onConfirm, onCancel) {
	confirmMessage.innerHTML = message;
	customConfirmModal.style.display = 'flex';
	
	const handleConfirm = () => {
		customConfirmModal.style.display = 'none';
		confirmYesButton.removeEventListener('click', handleConfirm);
		confirmNoButton.removeEventListener('click', handleCancel);
		onConfirm();
	};
	
	const handleCancel = () => {
		customConfirmModal.style.display = 'none';
		confirmYesButton.removeEventListener('click', handleConfirm);
		confirmNoButton.removeEventListener('click', handleCancel);
		onCancel();
	};
	
	confirmYesButton.addEventListener('click', handleConfirm);
	confirmNoButton.addEventListener('click', handleCancel);
}

// Close alert when OK button is clicked
alertOkButton.addEventListener('click', () => {
	customAlertModal.style.display = 'none';
});

// Close alert when close button is clicked
closeAlertButton.addEventListener('click', () => {
	customAlertModal.style.display = 'none';
});

// Close modals if user clicks outside the modal content
window.addEventListener('click', (event) => {
	if (event.target === customAlertModal) {
		customAlertModal.style.display = 'none';
	}
	if (event.target === customConfirmModal) {
		customConfirmModal.style.display = 'none';
	}
});

/**
 * Displays a custom confirmation modal with a message and callbacks for true/false.
 * @param {boolean} show - The boolean to display.
 */
function showLoading(show) {
	if (show) {
		loaderContainer.style.display = 'flex';
	} else {
		loaderContainer.style.display = 'none';
	}
}


//for drop-down toggling
const userProfileIcon = document.getElementById('userProfileIcon');
const dropdownSidebar = document.getElementById('dropdownSidebar');

// Toggle dropdown visibility
userProfileIcon.addEventListener('click', (event) => {
	// Prevent click from propagating to document and immediately closing
	event.stopPropagation();
	dropdownSidebar.classList.toggle('active');
});

// Close dropdown if clicked outside
document.addEventListener('click', (event) => {
	if (!userProfileIcon.contains(event.target) && !dropdownSidebar.contains(event.target)) {
		dropdownSidebar.classList.remove('active');
	}
});

//for account recharge
function copyText(elementId) {
	var textToCopy = document.getElementById(elementId).value;
	navigator.clipboard.writeText(textToCopy).then(() => {
		showAlert(textToCopy + ' ' + 'Copied Successfully');
	}).catch(err => {
		console.error('Failed to copy text: ', err);
	});
}

// --- subTab Switching Functionality ---
function switchSubTab(tabId) {
	document.querySelectorAll('.box-tab').forEach(div => {
		div.classList.add('hidden');
	});
	document.getElementById(tabId).classList.remove('hidden');
	
}

// Add functionality to filter buttons
document.querySelectorAll('.filter-button').forEach(button => {
	button.addEventListener('click', function() {
		// Remove 'active' class from all buttons
		document.querySelectorAll('.filter-button').forEach(btn => {
			btn.classList.remove('active');
		});
		// Add 'active' class to the clicked button
		this.classList.add('active');
		const activeTab = this.dataset.sub;
		// console.log(`Switched to tab: ${activeTab}`);
		switchSubTab(activeTab);
		console.log(`Filter selected: ${this.textContent}`);
	});
});

/**
 * Switches the active page, handles loader, updates history, and persists state.
 * This function is exported to be potentially used by other modules.
 * @param {string} pageId - The ID of the page container to show (e.g., 'home-page').
 * @param {boolean} [isPopState=false] - True if called from popstate event, false otherwise.
 */
const pageContainers = document.querySelectorAll('.container');
// All page content divs
// --- Tab Switching Functionality
function showPage(pageId, isPopState = false) {
	if (!navigator.online) {
		console.warn('Something went wrong, Please Connect to the internet');
		//   showAlert('Something went wrong, Please Connect to the internet');
		// return;
	}
	// Ensure the pageId corresponds to an existing page
	const targetPageElement = document.getElementById(pageId);
	if (!targetPageElement) {
		console.error(`Page with ID "${pageId}" not found. Defaulting to home-page.`);
		pageId = 'homeTab'; // Default to home if invalid pageId
	}
	showLoading(true);
	setTimeout(function() {
		pageContainers.forEach(div => {
			div.classList.add('hidden');
		});
		// Show the target page container and apply fade-in
		document.getElementById(pageId).classList.remove('hidden');
		localStorage.setItem('savedTab', JSON.stringify(pageId));
		showLoading(false);
		
		// Update active navigation link
		tabItems.forEach(item => {
			if (item.dataset.page === pageId) {
				item.classList.add('active');
			}
			else {
				//    item.classList.remove('active');
			}
		});
		// Update document title
		document.title = `Timeego - ${pageId.replace('-page', '').charAt(0).toUpperCase() + pageId.replace('Tab', ' Page').slice(1)}`;
		
		urlParams.set("tab", pageId);
		const updatedUrl = window.location.origin + window.location.pathname + '?' + urlParams.toString();
		console.log(updatedUrl)
		window.history.pushState({}, '', updatedUrl);
		
		// Only push state if not a popstate event (to avoid adding duplicate history entries)
		if (!isPopState) {
			history.pushState({ page: pageId }, '', `#${pageId}`);
		}
	}, 1500); //2000
}

tabItems.forEach(item => {
	item.addEventListener('click', () => {
		tabItems.forEach(i => i.classList.remove('active'));
		item.classList.add('active');
		//to prevent uneven load
		//	item.setAttribute('disabled', true);
		const activeTab = item.dataset.tab;
		showPage(activeTab); // Use the exported pageId
		
	});
});

const savedTab = JSON.parse(localStorage.getItem("savedTab"))
window.onpopstate = function(event) {
	if (event.state && event.state.page) {
		showPage(event.state.page, true); // Pass true to indicate it's a popstate event
	} else {
		const pathPage = window.location.hash.substring(1) || 'homeTab';
		showPage(pathPage, true);
	}
};
//for page back navigation 
document.querySelectorAll('.go-back').forEach((backBtn) => {
	backBtn.addEventListener('click', () => {
		history.back();
	})
});


const autoPage = !tabParam ? savedTab : tabParam;
if (autoPage) {
	tabItems.forEach(item => {
		item.classList.remove('active');
		if (item.dataset.tab === autoPage) {
			item.classList.add('active');
		}
	});
}
const initialPageFromHash = window.location.hash.substring(1);
const initialPage = initialPageFromHash || autoPage || 'login-page';
history.replaceState({ page: initialPage }, '', `#${initialPage}`);
// Render the initial page
showPage(initialPage);
//showPage("upgrade-page")


document.addEventListener('DOMContentLoaded', () => {
	showLoading(true)
});